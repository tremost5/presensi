<?= $this->extend('layouts/adminlte') ?>
<?= $this->section('content') ?>

<h3 class="mb-3">📋 Audit Log Absensi</h3>

<form method="get" class="mb-3">
  <label>Tanggal:</label>
  <input type="date" name="tanggal" value="<?= esc($tanggal) ?>">
  <button class="btn btn-primary btn-sm">Tampilkan</button>
</form>

<?php if (empty($logs)): ?>
  <div class="alert alert-success">Tidak ada aktivitas.</div>
<?php else: ?>

<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
  <th>Waktu</th>
  <th>Murid</th>
  <th>Kelas</th>
  <th>Lokasi</th>
  <th>Guru</th>
  <th>Aksi</th>
  <th>Status</th>
  <th>Oleh</th>
</tr>
</thead>
<tbody>

<?php
$kelasMap = [
  1=>'PG',2=>'TKA',3=>'TKB',
  4=>'1',5=>'2',6=>'3',7=>'4',8=>'5',9=>'6'
];

$lokasiMap = [
  1=>'NICC',
  2=>'GRASA',
  3=>'CPM'
];
?>

<?php foreach ($logs as $l): ?>
<tr>
    <td><?= esc($l['created_at']) ?></td>
    <td><?= esc($l['murid_nama'] ?? '-') ?></td>
    <td><?= esc($l['kode_kelas'] ?? '-') ?></td>
    <td><?= esc($l['lokasi_nama'] ?? '-') ?></td>
    <td><?= esc($l['guru_nama'] ?? '-') ?></td>
    <td><?= esc($l['aksi'] ?? '-') ?></td>
    <td><?= esc($l['status_baru'] ?? '-') ?></td>
    <td><?= esc($l['oleh'] ?? '-') ?></td>

</tr>
<?php endforeach ?>

</tbody>
</table>

<?php endif ?>

<a href="<?= base_url('dashboard/admin') ?>" class="btn btn-secondary btn-sm mt-3">
⬅️ Kembali
</a>

<?= $this->endSection() ?>
