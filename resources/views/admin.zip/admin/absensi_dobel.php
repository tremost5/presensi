<?= $this->extend('layouts/adminlte') ?>
<?= $this->section('content') ?>

<h3 class="mb-3 text-danger">⚠️ Absensi Dobel</h3>

<form method="get" class="mb-3">
  <label>Tanggal:</label>
  <input type="date" name="tanggal" value="<?= esc($tanggal) ?>">
  <button class="btn btn-primary btn-sm">Tampilkan</button>
</form>

<?php if (empty($data)): ?>

  <div class="alert alert-success">
    Tidak ada konflik.
  </div>

<?php else: ?>
<?php
$kelasLabel = [
    1 => 'PG',
    2 => 'TKA',
    3 => 'TKB',
    4 => '1',
    5 => '2',
    6 => '3',
    7 => '4',
    8 => '5',
    9 => '6',
];
?>

<?php foreach ($data as $row): ?>

<div class="card mb-3 border-warning">

  <div class="card-header bg-warning">
    <strong><?= esc($row['murid_nama']) ?></strong>
Kelas Kelas <strong><?= esc($kelasLabel[$row['kelas_id']] ?? '-') ?></strong>

Tanggal <?= esc($row['tanggal']) ?>

  </div>

  <div class="card-body p-0">
    <table class="table table-bordered mb-0">
      <thead>
        <tr>
          <th>Jam</th>
          <th>Lokasi</th>
          <th>Guru</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>

      <?php foreach ($row['items'] as $it): ?>
        <tr>
          <td><?= esc($it['created_at']) ?></td>
          <td><?= esc($it['lokasi_id']) ?></td>
          <td><?= esc($it['guru']) ?></td>
          <td>
            <form method="post" action="<?= base_url('dashboard/admin/absensi-dobel/resolve') ?>">
              <?= csrf_field() ?>
              <input type="hidden" name="detail_id" value="<?= $it['detail_id'] ?>">
              <input type="hidden" name="murid_id" value="<?= $row['murid_id'] ?>">
              <input type="hidden" name="tanggal" value="<?= $row['tanggal'] ?>">

              <button
                class="btn btn-success btn-sm"
                onclick="return confirm('Tetapkan absensi ini sebagai HADIR?')">
                ✔ Jadikan HADIR
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>

      </tbody>
    </table>
  </div>

</div>

<?php endforeach; ?>
<?php endif; ?>

<a href="<?= base_url('dashboard/admin') ?>" class="btn btn-secondary btn-sm mt-3">
  ⬅️ Kembali
</a>

<?= $this->endSection() ?>
